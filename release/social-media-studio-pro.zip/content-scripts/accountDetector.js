"use strict";
(() => {
  // src/shared/constants.ts
  var MESSAGE_TYPES = {
    ENQUEUE_TASKS: "ENQUEUE_TASKS",
    PAUSE_TASK: "PAUSE_TASK",
    RESUME_TASK: "RESUME_TASK",
    CANCEL_TASK: "CANCEL_TASK",
    RETRY_TASK: "RETRY_TASK",
    REORDER_TASK: "REORDER_TASK",
    QUEUE_UPDATED: "QUEUE_UPDATED",
    ACTIVITY_APPENDED: "ACTIVITY_APPENDED",
    CONNECT_PLATFORM: "CONNECT_PLATFORM",
    DISCONNECT_PLATFORM: "DISCONNECT_PLATFORM",
    AUTH_STATE_UPDATED: "AUTH_STATE_UPDATED",
    FETCH_ANALYTICS: "FETCH_ANALYTICS",
    DETECTED_ACCOUNT: "DETECTED_ACCOUNT",
    RUN_SCHEDULER_TICK: "RUN_SCHEDULER_TICK"
  };

  // src/content-scripts/accountDetector.ts
  function detectPlatform() {
    const host = location.hostname;
    if (host.includes("youtube.com")) return "youtube";
    if (host.includes("facebook.com")) return "facebook";
    if (host.includes("tiktok.com")) return "tiktok";
    return null;
  }
  function detectAccountLabel(platform) {
    try {
      if (platform === "youtube") {
        const avatarImg = document.querySelector(
          "#avatar-btn img, ytd-topbar-menu-button-renderer img, tp-yt-paper-icon-button#avatar-btn img"
        );
        return avatarImg?.alt || null;
      }
      if (platform === "facebook") {
        const profileLink = document.querySelector('[aria-label="Your profile"], [data-testid="user-name-link"]');
        return profileLink?.getAttribute("aria-label") || profileLink?.textContent?.trim() || null;
      }
      if (platform === "tiktok") {
        const avatarImg = document.querySelector('[data-e2e="profile-icon"] img, .avatar img');
        return avatarImg?.alt || null;
      }
    } catch {
      return null;
    }
    return null;
  }
  function reportDetection() {
    const platform = detectPlatform();
    if (!platform) return;
    const accountLabel = detectAccountLabel(platform);
    chrome.runtime.sendMessage({
      type: MESSAGE_TYPES.DETECTED_ACCOUNT,
      payload: { platform, accountLabel, url: location.href }
    }).catch(() => {
    });
  }
  var debounceTimer;
  function scheduleReport() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(reportDetection, 1500);
  }
  scheduleReport();
  new MutationObserver(scheduleReport).observe(document.documentElement, { childList: true, subtree: true });
})();
//# sourceMappingURL=accountDetector.js.map
